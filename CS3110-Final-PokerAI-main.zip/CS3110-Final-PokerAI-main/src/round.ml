type player = {name : string; hand : Deck.card list; money : int}

type player_list = player list

(**type round = {card_deck : Deck.deck; all_players : player_list; active_players : player_list; community_cards : Deck.card list; pot : int; bet : int}*)

type round = {card_deck : Deck.deck; all_players : player_list; active_players : player_list; community_cards : Deck.card list}

