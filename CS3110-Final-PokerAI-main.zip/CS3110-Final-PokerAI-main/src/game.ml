type player = {name : string; hand : Deck.card list; money : int}

type player_list = player list

(**type round = {card_deck : Deck.deck; all_players : player_list; active_players : player_list; community_cards : Deck.card list; pot : int; bet : int}*)

type round = {card_deck : Deck.card list; all_players : player_list; active_players : player_list; community_cards : Deck.card list}

exception Empty

(**monetary things, small blind big blind*)
type game = round

let player1 = {name = "Michael"; hand = []; money =1000}
let player2 = {name = "Ethan"; hand = []; money = 1000}
let player3 = {name = "Andrew"; hand = []; money = 1000}

let player_list = [player1;player2;player3]
let start = {card_deck = Deck.shuffled; all_players = [player1; player2]; active_players = [player1; player2]; community_cards = []}

(** Deals a single card to a single player, returns a new player with updated hand.*)
let deal_single player deck =
  match deck with
  | [] -> raise Empty
  | h :: _ -> {name = player.name; hand = h :: player.hand; money = player.money}

  (** Removes the first n cards from the top of the deck*)
  let rec remove_n_cards n deck =
  if n = 0 then deck else remove_n_cards (n-1) (List.tl deck)

(** Deals the preflop hands to all players in the player list. deal_single
all is applying deal_single to all players in the deck whilst ensuring deck is
also being popped accordingly, so it returns a new list of players each with
updated hand. in final statement, im calling deal_single_all twice somewhat.
first call is within the parameter, second call is the actual statement itself
  with list of players who have 1 card in hand and deck with the top cards already
  removed. if confused, try testing deal_single_all first*)
let deal_preflop_hands player_list deck = 
  let rec deal_single_all player_list deck = 
    match player_list with
    | [] -> player_list
    | h :: t -> (deal_single h deck) :: (deal_single_all t (List.tl deck))
  in deal_single_all (deal_single_all player_list deck) (remove_n_cards (List.length player_list) deck)

(** returns the cards on the flop after dealing all preflop and burning 1 card*)
let flop_cards player_list deck = 
  let num_players = List.length player_list in
    List.nth deck (2*num_players+1) :: List.nth deck (2*num_players+2) :: [List.nth deck (2*num_players+3)]

(** returns card on turn after having dealt preflop hands, flop and burnt another one*)
let turn_card player_list deck = 
  let num_players = List.length player_list in [List.nth deck (2*num_players+5)]

(** returns river card, similar to above but river*)
let river_card player_list deck = 
  let num_players = List.length player_list in [List.nth deck (2*num_players+7)]

(** community_cards is flop + turn + river in that order cuz i like it that way instead of reversed*)
let community_cards player_list deck =
  flop_cards player_list deck |> (@) (turn_card player_list deck) |> (@) (river_card player_list deck) |> List.rev

(** these methods work, but have not been incorporated into the actual round object*)