type bet_amount = float

type command = 
  | Check
  | Fold
  | Bet of bet_amount
  | Call
  | Raise of bet_amount

exception Empty

exception Malformed

let lone_commands = ["check";"fold";"call"]

let phrase_commands = ["bet";"raise"]

let parse str =
  match
    List.filter (fun x -> x <> "") (String.split_on_char ' ' str)
  with
  | [] -> raise Empty
  | [ x ] -> if List.mem x lone_commands then
    match x with
    | "check" -> Check
    | "fold" -> Fold
    | "call" -> Call
    | _ -> raise Malformed
    else raise Malformed
  | h :: t -> if List.mem h phrase_commands && List.length t = 1 then
    match h with
    | "bet" -> Bet (t |> List.hd |> float_of_string)
    | "raise" -> Raise (t |> List.hd |>float_of_string)
    | _ -> raise Malformed
  else raise Malformed

let string_of_command = function
  | Check -> "I check!"
  | Fold -> "I fold!"
  | Bet amount -> "I bet " ^ string_of_float amount ^ "!"
  | Call -> "I call!"
  | Raise amount -> "I raise!" ^ string_of_float amount ^ "!"