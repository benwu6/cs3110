
type suits = Club | Diamond | Spade | Heart
type ranks = Two | Three | Four | Five | Six | Seven | Eight | Nine | Ten | Jack | Queen | King | Ace
type card = 
  {s : suits;
  r : ranks;
  }

let suit = [Club; Diamond; Spade; Heart]
let rank = [Two; Three; Four; Five; Six; Seven; Eight; Nine; Ten; Jack; Queen; King; Ace]



(**helper function in creating list*)
let rec sandc rlst s = match rlst with
|[] -> []
| h :: t -> {s = s; r = h} :: sandc t s

(**create base deck with 52 cards*)
let basedeck = sandc rank Diamond @ sandc rank Club @ sandc rank Heart @ sandc rank Spade

(**shuffle the cards in a randomized order*)
let shuffled =                        
  let nd = List.map (fun c -> (Random.bits (), c)) basedeck in
  let sond = List.sort compare nd in
  List.map snd sond (**found code from stack overflow by author Jackson Tale*)

type deck = {clst : card list; top : card}

type player_hands = card list list

type player_hand = card list

type community_cards = card list