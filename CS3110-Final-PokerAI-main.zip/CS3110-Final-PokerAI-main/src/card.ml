exception InvalidCard 

type suit = Club | Diamond | Spade | Heart
type rank = Ace | Two | Three | Four | Five | Six | Seven | Eight | Nine | Ten | Jack | Queen | King
type card = 
  {s : suit;
  r : rank;
  }


let is_valid_card card:card  = 
  match card with 
  | {s : suit; r : rank} -> if ((s= Club || s =Diamond || s = Spade || s= Heart)
    ) && (r= Ace || r= Two (*I haven't finished this part yet*)) then card else raise InvalidCard




